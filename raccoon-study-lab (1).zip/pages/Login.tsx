
import React, { useState } from 'react';
import { Page, Language } from '../types';
import { RaccoonIcon } from '../constants';
import { translations } from '../translations';

interface LoginProps {
  onLogin: () => void;
  setCurrentPage: (page: Page) => void;
  lang: Language;
}

const Login: React.FC<LoginProps> = ({ onLogin, setCurrentPage, lang }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const t = translations[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
    setCurrentPage(Page.HOME);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-md bg-white rounded-3xl p-8 md:p-12 shadow-2xl shadow-blue-100 border border-blue-50 animate-in zoom-in-95 duration-300">
        <div className="flex flex-col items-center mb-10">
          <div className="bg-blue-600 text-white p-3 rounded-2xl mb-4 shadow-lg shadow-blue-200">
            <RaccoonIcon className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-800">{t.loginTitle}</h1>
          <p className="text-slate-500 text-sm">{t.loginSub}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700 ml-1">{t.email}</label>
            <input 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="raccoon@study.lab"
              className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm"
              required
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <label className="text-sm font-medium text-slate-700">{t.password}</label>
              <button type="button" className="text-xs font-semibold text-blue-600 hover:underline">{t.forgot}</button>
            </div>
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm"
              required
            />
          </div>

          <button 
            type="submit"
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
          >
            {t.signInBtn}
          </button>
        </form>

        <div className="mt-8 text-center text-sm text-slate-500">
          {t.newHere} <button className="text-blue-600 font-bold hover:underline">{t.createAccount}</button>
        </div>
      </div>
    </div>
  );
};

export default Login;
