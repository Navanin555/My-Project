
import React from 'react';
import { MOCK_PRODUCTS } from '../constants';
import { Product, Language } from '../types';
import { translations } from '../translations';

interface HotProductsProps {
  lang: Language;
  addToCart: (product: Product) => void;
  onViewDetail: (product: Product) => void;
}

const HotProducts: React.FC<HotProductsProps> = ({ lang, addToCart, onViewDetail }) => {
  const hotProducts = MOCK_PRODUCTS.filter(p => p.isHot);
  const t = translations[lang];

  return (
    <div className="px-6 py-12 max-w-7xl mx-auto animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
        <div>
          <h1 className="text-3xl font-bold text-blue-900 mb-2">{t.popularHits}</h1>
          <p className="text-slate-500">{t.communityLoved}</p>
        </div>
        <div className="flex items-center gap-2">
           <span className="text-sm text-slate-400">{t.sortBy}:</span>
           <select className="bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
             <option>Best Selling</option>
             <option>Price: Low to High</option>
             <option>Top Rated</option>
           </select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {hotProducts.map((product) => (
          <ProductCard key={product.id} product={product} addToCart={addToCart} lang={lang} onViewDetail={onViewDetail} />
        ))}
      </div>
    </div>
  );
};

const ProductCard: React.FC<{ product: Product, addToCart: (product: Product) => void, lang: Language, onViewDetail: (product: Product) => void }> = ({ product, addToCart, lang, onViewDetail }) => {
  const t = translations[lang];
  return (
    <div className="group bg-white rounded-3xl overflow-hidden border border-blue-50 hover:shadow-xl hover:shadow-blue-100 transition-all duration-300 flex flex-col">
      <div 
        className="relative aspect-square overflow-hidden bg-slate-50 cursor-pointer"
        onClick={() => onViewDetail(product)}
      >
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {product.isHot && (
          <span className="absolute top-4 left-4 bg-orange-500 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest shadow-lg">
            Hot
          </span>
        )}
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-bold text-blue-500 uppercase tracking-wide">{product.category}</span>
          <div className="flex items-center gap-1">
            <span className="text-yellow-400">★</span>
            <span className="text-xs font-bold text-slate-600">{product.rating}</span>
          </div>
        </div>
        <h3 
          className="text-lg font-bold text-slate-800 mb-2 cursor-pointer group-hover:text-blue-600 transition-colors"
          onClick={() => onViewDetail(product)}
        >
          {product.name}
        </h3>
        <p className="text-sm text-slate-500 line-clamp-2 mb-4 leading-relaxed">
          {product.description}
        </p>
        <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
          <span className="text-xl font-bold text-blue-900">฿{product.price}</span>
          <button 
            onClick={() => addToCart(product)}
            className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-blue-600 hover:text-white transition-all active:scale-95"
          >
            {t.addToCart}
          </button>
        </div>
      </div>
    </div>
  );
};

export default HotProducts;
