
import React, { useState } from 'react';
import { Product, Language, Page } from '../types';
import { translations } from '../translations';
import { RaccoonIcon, MOCK_PRODUCTS } from '../constants';

interface ProductDetailProps {
  product: Product;
  lang: Language;
  addToCart: (product: Product) => void;
  setCurrentPage: (page: Page) => void;
  onViewDetail: (product: Product) => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ 
  product, 
  lang, 
  addToCart, 
  setCurrentPage,
  onViewDetail
}) => {
  const t = translations[lang];
  const [quantity, setQuantity] = useState(1);

  const relatedProducts = MOCK_PRODUCTS
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 3);

  const handleAddToCart = () => {
    // We update quantity by adding one at a time in the current App logic, 
    // but here we can just call it multiple times or we could adjust the App's addToCart.
    // For simplicity with existing App code, we'll just add the item.
    for(let i=0; i<quantity; i++) {
        addToCart(product);
    }
  };

  return (
    <div className="px-6 py-12 max-w-7xl mx-auto animate-in fade-in duration-500">
      <button 
        onClick={() => setCurrentPage(Page.CATEGORIES)}
        className="flex items-center gap-2 text-slate-400 hover:text-blue-600 font-bold text-sm mb-8 transition-colors group"
      >
        <span className="group-hover:-translate-x-1 transition-transform">←</span>
        {t.backToList}
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-square bg-white rounded-[3rem] overflow-hidden border border-blue-50 shadow-sm">
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="aspect-square bg-slate-100 rounded-2xl overflow-hidden border border-slate-200 cursor-pointer opacity-50 hover:opacity-100 transition-opacity">
                <img src={product.imageUrl} alt="Gallery" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="bg-white rounded-[3rem] border border-blue-50 p-8 md:p-12 shadow-sm sticky top-24">
          <div className="flex items-center justify-between mb-4">
            <span className="bg-blue-50 text-blue-600 px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
              {product.category}
            </span>
            <div className="flex items-center gap-1.5">
              <span className="text-yellow-400 text-lg">★</span>
              <span className="font-bold text-slate-700">{product.rating}</span>
            </div>
          </div>

          <h1 className="text-3xl md:text-4xl font-black text-slate-800 mb-4 tracking-tight">
            {product.name}
          </h1>

          <div className="flex items-center gap-4 mb-8">
            {product.discountPrice ? (
              <>
                <span className="text-3xl font-black text-blue-900">฿{product.discountPrice}</span>
                <span className="text-xl text-slate-400 line-through">฿{product.price}</span>
                <span className="bg-orange-500 text-white text-[10px] font-black px-2 py-1 rounded-lg">SALE</span>
              </>
            ) : (
              <span className="text-3xl font-black text-blue-900">฿{product.price}</span>
            )}
            <span className="ml-auto text-green-500 font-bold text-xs flex items-center gap-1">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              {t.inStock}
            </span>
          </div>

          <div className="space-y-6 mb-10">
            <div>
              <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-2">{t.description}</h3>
              <p className="text-slate-600 leading-relaxed">
                {product.description}
              </p>
            </div>

            <div className="bg-blue-50/50 rounded-3xl p-6 border border-blue-100/50">
                <div className="flex items-center gap-3 mb-2">
                    <RaccoonIcon className="w-6 h-6 text-blue-600" />
                    <h4 className="font-black text-blue-900 text-sm uppercase tracking-tight">{t.rockyNote}</h4>
                </div>
                <p className="text-xs text-blue-700 leading-relaxed italic">
                    {lang === 'th' 
                        ? "ร็อกกี้แนะนำเลย! ชิ้นนี้เหมาะมากสำหรับการจัดระเบียบโต๊ะเรียนให้ดูสะอาดตาและมินิมอลสุดๆ 🦝" 
                        : "Rocky recommends! This piece is perfect for organizing your desk and keeping it clean and minimalist. 🦝"}
                </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="flex items-center gap-4 bg-slate-50 border border-slate-100 rounded-2xl px-4 py-2 w-full sm:w-auto">
              <button 
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="text-blue-600 font-black text-xl w-8 h-8 flex items-center justify-center hover:bg-white rounded-lg transition-colors"
              >-</button>
              <span className="font-black text-slate-800 w-6 text-center">{quantity}</span>
              <button 
                onClick={() => setQuantity(q => q + 1)}
                className="text-blue-600 font-black text-xl w-8 h-8 flex items-center justify-center hover:bg-white rounded-lg transition-colors"
              >+</button>
            </div>
            <button 
              onClick={handleAddToCart}
              className="flex-1 w-full bg-blue-600 text-white py-4 rounded-2xl font-black shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
            >
              <span>{t.addToCart}</span>
              <span className="text-lg">🛒</span>
            </button>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <section className="mt-24">
        <h2 className="text-2xl font-black text-slate-800 mb-8">{t.relatedProducts}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {relatedProducts.map((p) => (
            <div 
              key={p.id} 
              onClick={() => onViewDetail(p)}
              className="group bg-white rounded-3xl overflow-hidden border border-blue-50 hover:shadow-xl transition-all cursor-pointer"
            >
              <div className="aspect-square overflow-hidden bg-slate-50">
                <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              </div>
              <div className="p-6">
                <h4 className="font-bold text-slate-800 group-hover:text-blue-600 transition-colors">{p.name}</h4>
                <p className="text-blue-900 font-black mt-1">฿{p.discountPrice || p.price}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default ProductDetail;
