
import React from 'react';
import { Language, Page } from '../types';
import { translations } from '../translations';

interface AccountProps {
  lang: Language;
  setCurrentPage: (page: Page) => void;
}

const Account: React.FC<AccountProps> = ({ lang, setCurrentPage }) => {
  const t = translations[lang];

  const menuItems = [
    { label: t.navOrders, page: Page.ACCOUNT },
    { label: 'Shipping Address', page: Page.ACCOUNT },
    { label: 'Payment Methods', page: Page.ACCOUNT },
    { label: t.settings, page: Page.SETTINGS },
    { label: 'Security', page: Page.ACCOUNT }
  ];

  return (
    <div className="px-6 py-12 max-w-5xl mx-auto animate-in fade-in duration-500">
      <h1 className="text-3xl font-bold text-blue-900 mb-8">{t.myAccount}</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <aside className="lg:col-span-1 space-y-2">
          {menuItems.map((item, idx) => (
            <button 
              key={item.label} 
              onClick={() => setCurrentPage(item.page)}
              className={`w-full text-left px-5 py-3 rounded-xl text-sm font-medium transition-all ${idx === 0 ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' : 'text-slate-500 hover:bg-white hover:text-blue-600'}`}
            >
              {item.label}
            </button>
          ))}
        </aside>

        <main className="lg:col-span-3 space-y-6">
          <div className="bg-white rounded-3xl border border-blue-50 p-8">
            <h2 className="text-xl font-bold text-slate-800 mb-6">{t.navOrders}</h2>
            
            <div className="space-y-6">
              {[1, 2].map((order) => (
                <div key={order} className="flex flex-col sm:flex-row items-center justify-between gap-6 p-6 rounded-2xl border border-slate-50 bg-slate-50/30">
                  <div className="flex items-center gap-6">
                    <div className="w-20 h-20 bg-white rounded-xl border border-slate-100 overflow-hidden">
                      <img 
                        src={`https://images.unsplash.com/photo-${order === 1 ? '1544816153-199d88949e5f' : '1585336261022-69c66d117f6c'}?auto=format&fit=crop&q=80&w=150&h=150`} 
                        alt="Order Item" 
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-800">Order #RL-492{order}</div>
                      <div className="text-xs text-slate-500 mt-1">Placed on May 24, 2024</div>
                      <div className="mt-2 inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                         {t.delivered}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-3 w-full sm:w-auto">
                    <div className="text-lg font-bold text-blue-900">฿1,450</div>
                    <button className="text-sm font-bold text-blue-600 hover:underline">{t.viewDetails}</button>
                  </div>
                </div>
              ))}
            </div>
            <button className="mt-8 w-full py-4 border-2 border-dashed border-slate-100 text-slate-400 font-bold rounded-2xl hover:bg-slate-50 transition-all">
              {t.loadMore}
            </button>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Account;
