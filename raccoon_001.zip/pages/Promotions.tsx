
import React from 'react';
import { MOCK_PRODUCTS } from '../constants';
import { Product, Language } from '../types';
import { translations } from '../translations';

interface PromotionsProps {
  lang: Language;
  addToCart: (product: Product) => void;
  onViewDetail: (product: Product) => void;
}

const Promotions: React.FC<PromotionsProps> = ({ lang, addToCart, onViewDetail }) => {
  const t = translations[lang];
  const promoProducts = MOCK_PRODUCTS.filter(p => p.discountPrice !== undefined);

  return (
    <div className="animate-in fade-in duration-500 pb-20">
      <section className="bg-gradient-to-b from-blue-900 to-blue-800 text-white px-6 py-16 text-center overflow-hidden relative">
        <div className="max-w-4xl mx-auto relative z-10">
          <div className="inline-block bg-orange-500 text-white px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
            Flash Sale
          </div>
          <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight uppercase italic">
            {t.promoTitle}
          </h1>
          <p className="text-blue-100 mb-8 max-w-lg mx-auto font-medium">
            {t.promoSub}
          </p>
          <div className="flex justify-center gap-4">
            <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20">
              <span className="text-2xl font-black block">02</span>
              <span className="text-[8px] uppercase font-bold tracking-widest text-blue-200">Hours</span>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20">
              <span className="text-2xl font-black block">45</span>
              <span className="text-[8px] uppercase font-bold tracking-widest text-blue-200">Mins</span>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20">
              <span className="text-2xl font-black block">12</span>
              <span className="text-[8px] uppercase font-bold tracking-widest text-blue-200">Secs</span>
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-400/20 rounded-full -mr-32 -mt-32 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-orange-400/20 rounded-full -ml-32 -mb-32 blur-3xl" />
      </section>

      <div className="px-6 py-12 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {promoProducts.map((product) => (
            <PromoCard key={product.id} product={product} addToCart={addToCart} lang={lang} onViewDetail={onViewDetail} />
          ))}
        </div>
      </div>
    </div>
  );
};

const PromoCard: React.FC<{ product: Product, addToCart: (product: Product) => void, lang: Language, onViewDetail: (product: Product) => void }> = ({ product, addToCart, lang, onViewDetail }) => {
  const t = translations[lang];
  const discountPercent = product.discountPrice 
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;

  return (
    <div className="group bg-white rounded-3xl overflow-hidden border border-blue-50 hover:shadow-2xl hover:shadow-blue-100/50 transition-all duration-500 flex flex-col h-full">
      <div 
        className="relative aspect-square overflow-hidden bg-slate-50 cursor-pointer"
        onClick={() => onViewDetail(product)}
      >
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute top-4 right-4 bg-orange-500 text-white text-xs font-black px-3 py-1.5 rounded-xl shadow-lg transform rotate-6">
          -{discountPercent}%
        </div>
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">{product.category}</span>
        <h3 
            className="text-lg font-bold text-slate-800 mb-2 line-clamp-1 group-hover:text-blue-600 transition-colors cursor-pointer"
            onClick={() => onViewDetail(product)}
        >
          {product.name}
        </h3>
        <p className="text-xs text-slate-500 line-clamp-2 mb-4 leading-relaxed">
          {product.description}
        </p>
        <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 line-through">฿{product.price}</span>
            <span className="text-xl font-black text-blue-900">฿{product.discountPrice}</span>
          </div>
          <button 
            onClick={() => addToCart(product)}
            className="bg-blue-600 text-white px-5 py-2.5 rounded-xl text-xs font-bold hover:bg-blue-700 transition-all active:scale-95 shadow-md shadow-blue-100"
          >
            {t.buyNow}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Promotions;
