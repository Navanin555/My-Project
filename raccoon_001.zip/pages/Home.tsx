
import React, { useState } from 'react';
import { Page, Language } from '../types';
import { RaccoonIcon } from '../constants';
import { getRaccoonAdvice } from '../services/geminiService';
import { translations } from '../translations';

interface HomeProps {
  setCurrentPage: (page: Page) => void;
  lang: Language;
  onCategorySelect: (category: string) => void;
}

const Home: React.FC<HomeProps> = ({ setCurrentPage, lang, onCategorySelect }) => {
  const [advice, setAdvice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const t = translations[lang];

  const fetchAdvice = async () => {
    setLoading(true);
    const text = await getRaccoonAdvice("Student", lang === 'th' ? "อุปกรณ์ไอทีและชุดนักเรียนใหม่" : "IT gadgets and new school uniforms");
    setAdvice(text);
    setLoading(false);
  };

  const categories = [
    { name: t.catNotebooks, raw: 'Notebooks', icon: '📖', color: 'bg-blue-100' },
    { name: t.catWriting, raw: 'Pens', icon: '✍️', color: 'bg-indigo-100' },
    { name: t.catIT, raw: 'IT', icon: '💻', color: 'bg-slate-100' },
    { name: t.catUniforms, raw: 'Uniforms', icon: '👕', color: 'bg-cyan-100' },
  ];

  return (
    <div className="animate-in fade-in duration-500">
      <section className="bg-white border-b border-blue-50 px-6 py-12 md:py-24 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-6">
            <RaccoonIcon className="w-4 h-4" />
            {t.heroBadge}
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-blue-900 mb-6 leading-tight">
            {lang === 'en' ? (
              <>Elevate Your Study Game <br /> with <span className="text-blue-500 italic">Raccoon Style</span></>
            ) : (
              <>{t.heroTitle}</>
            )}
          </h1>
          <p className="text-slate-500 text-lg mb-10 max-w-2xl mx-auto">
            {t.heroSubtitle}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={() => setCurrentPage(Page.HOT_PRODUCTS)}
              className="w-full sm:w-auto bg-blue-600 text-white px-8 py-3.5 rounded-2xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
            >
              {t.shopNow}
            </button>
            <button 
              onClick={fetchAdvice}
              disabled={loading}
              className="w-full sm:w-auto bg-white border border-blue-200 text-blue-600 px-8 py-3.5 rounded-2xl font-semibold hover:bg-blue-50 transition-all"
            >
              {loading ? t.askingRocky : t.aiAdvice}
            </button>
          </div>

          {advice && (
            <div className="mt-8 bg-blue-50 p-6 rounded-2xl border border-blue-100 text-blue-800 max-w-lg mx-auto animate-in slide-in-from-bottom-4 duration-300">
              <p className="italic">" {advice} "</p>
            </div>
          )}
        </div>
      </section>

      <section className="px-6 py-16 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-blue-900">{t.categories}</h2>
          <button 
            onClick={() => {
              onCategorySelect('All');
              setCurrentPage(Page.CATEGORIES);
            }} 
            className="text-blue-600 text-sm font-semibold hover:underline"
          >
            {t.viewAll}
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {categories.map((cat) => (
            <div 
              key={cat.name} 
              onClick={() => {
                onCategorySelect(cat.raw);
                setCurrentPage(Page.CATEGORIES);
              }}
              className={`${cat.color} p-8 rounded-3xl flex flex-col items-center justify-center text-center cursor-pointer hover:scale-105 transition-transform group`}
            >
              <span className="text-4xl mb-4 group-hover:rotate-12 transition-transform">{cat.icon}</span>
              <span className="font-bold text-slate-800">{cat.name}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
