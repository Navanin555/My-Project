
import React, { useState } from 'react';
import { CartItem, Language } from '../types';
import { translations } from '../translations';
import { RaccoonIcon } from '../constants';

interface CheckoutProps {
  lang: Language;
  cartItems: CartItem[];
}

type PaymentType = 'PROMPTPAY' | 'BANK' | 'CREDIT';

const Checkout: React.FC<CheckoutProps> = ({ lang, cartItems }) => {
  const t = translations[lang];
  const [selectedPayment, setSelectedPayment] = useState<PaymentType>('PROMPTPAY');
  const [isOrdered, setIsOrdered] = useState(false);
  const [address, setAddress] = useState({
    name: '',
    phone: '',
    detail: '',
    province: '',
    district: '',
    postal: ''
  });

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = 0;
  const total = subtotal + shipping;

  const handleConfirm = () => {
    if (!address.name || !address.phone || !address.detail) {
      alert(lang === 'th' ? 'กรุณากรอกข้อมูลที่อยู่ให้ครบถ้วน' : 'Please complete the shipping address.');
      return;
    }
    setIsOrdered(true);
  };

  if (isOrdered) {
    return (
      <div className="px-6 py-24 max-w-2xl mx-auto text-center animate-in zoom-in-95 duration-500">
        <div className="bg-white rounded-3xl p-12 border border-blue-50 shadow-xl shadow-blue-100/50">
          <div className="w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-lg shadow-blue-200">
             <RaccoonIcon className="w-12 h-12" fill="white" />
          </div>
          <h1 className="text-3xl font-black text-blue-900 mb-4">
            {lang === 'th' ? 'สั่งซื้อสำเร็จแล้ว!' : 'Order Successful!'}
          </h1>
          <p className="text-slate-500 mb-8 leading-relaxed">
            {lang === 'th' 
              ? 'ขอบคุณที่อุดหนุนเรานะครับ ร็อกกี้กำลังเตรียมแพ็คของให้คุณอย่างไวที่สุดเลย!' 
              : 'Thank you for your support! Rocky is packing your items as fast as he can!'}
          </p>
          <button 
            onClick={() => window.location.reload()} 
            className="bg-slate-50 text-slate-600 px-8 py-3 rounded-2xl font-bold hover:bg-blue-50 hover:text-blue-600 transition-all"
          >
            {t.backToHome}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-6 py-12 max-w-6xl mx-auto animate-in fade-in duration-500">
      <h1 className="text-3xl font-bold text-blue-900 mb-8">{t.waitingForPayment}</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          
          {/* Shipping Address Form */}
          <div className="bg-white rounded-3xl border border-blue-50 p-8 shadow-sm">
            <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              <span className="text-blue-600">📍</span> {t.shippingAddress}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1">{t.fullName}</label>
                <input 
                  type="text" 
                  value={address.name}
                  onChange={(e) => setAddress({...address, name: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" 
                  placeholder="Rocky Raccoon"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1">{t.phone}</label>
                <input 
                  type="text" 
                  value={address.phone}
                  onChange={(e) => setAddress({...address, phone: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" 
                  placeholder="081-234-5678"
                />
              </div>
              <div className="sm:col-span-2 space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1">{t.addressDetail}</label>
                <input 
                  type="text" 
                  value={address.detail}
                  onChange={(e) => setAddress({...address, detail: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" 
                  placeholder="123 Blue Valley, Rocky Street"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1">{t.district}</label>
                <input 
                  type="text" 
                  value={address.district}
                  onChange={(e) => setAddress({...address, district: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1">{t.province}</label>
                <input 
                  type="text" 
                  value={address.province}
                  onChange={(e) => setAddress({...address, province: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase ml-1">{t.postalCode}</label>
                <input 
                  type="text" 
                  value={address.postal}
                  onChange={(e) => setAddress({...address, postal: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" 
                />
              </div>
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="bg-white rounded-3xl border border-blue-50 p-8 shadow-sm">
            <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              <span className="text-blue-600">💳</span> {t.paymentMethod}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <button 
                onClick={() => setSelectedPayment('PROMPTPAY')}
                className={`flex flex-col items-center p-6 border-2 rounded-3xl transition-all ${selectedPayment === 'PROMPTPAY' ? 'border-blue-500 bg-blue-50/50' : 'border-slate-100 hover:border-blue-200'}`}
              >
                <span className="text-3xl mb-3">📱</span>
                <span className="text-xs font-bold text-slate-700">{t.qrPromptPay}</span>
              </button>
              <button 
                onClick={() => setSelectedPayment('BANK')}
                className={`flex flex-col items-center p-6 border-2 rounded-3xl transition-all ${selectedPayment === 'BANK' ? 'border-blue-500 bg-blue-50/50' : 'border-slate-100 hover:border-blue-200'}`}
              >
                <span className="text-3xl mb-3">🏦</span>
                <span className="text-xs font-bold text-slate-700">{t.bankTransfer}</span>
              </button>
              <button 
                onClick={() => setSelectedPayment('CREDIT')}
                className={`flex flex-col items-center p-6 border-2 rounded-3xl transition-all ${selectedPayment === 'CREDIT' ? 'border-blue-500 bg-blue-50/50' : 'border-slate-100 hover:border-blue-200'}`}
              >
                <span className="text-3xl mb-3">💳</span>
                <span className="text-xs font-bold text-slate-700">{t.creditCard}</span>
              </button>
            </div>

            {/* Detailed Payment Info */}
            <div className="mt-8 pt-8 border-t border-slate-50">
              {selectedPayment === 'PROMPTPAY' && (
                <div className="flex flex-col items-center text-center space-y-4 animate-in fade-in slide-in-from-top-4">
                  <div className="bg-blue-900 px-4 py-1.5 rounded-xl mb-2">
                     <span className="text-white font-black text-sm tracking-widest italic">Prompt Pay</span>
                  </div>
                  <div className="p-4 bg-white border-4 border-slate-100 rounded-3xl shadow-inner">
                    <img 
                      src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=RaccoonStudyLab" 
                      alt="PromptPay QR" 
                      className="w-48 h-48"
                    />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-slate-800">Raccoon Study Lab Co., Ltd.</p>
                    <p className="text-xs text-slate-500">Scan this QR code to pay ฿{total}</p>
                  </div>
                </div>
              )}

              {selectedPayment === 'BANK' && (
                <div className="space-y-6 animate-in fade-in slide-in-from-top-4">
                  <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100 flex items-center gap-6">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl shadow-lg">
                      🦝
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Raccoon Bank</p>
                      <p className="text-lg font-bold text-blue-900 tracking-wider">777-0-99999-0</p>
                      <p className="text-sm text-slate-600 font-medium">Account Name: Raccoon Study Lab</p>
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-slate-400">{lang === 'th' ? 'กรุณาโอนเงินและแนบหลักฐานการโอนเงินด้านล่าง' : 'Please transfer the funds and attach your slip below'}</p>
                  </div>
                </div>
              )}

              {selectedPayment === 'CREDIT' && (
                <div className="space-y-4 animate-in fade-in slide-in-from-top-4">
                  <div className="bg-slate-50 p-12 rounded-3xl border border-dashed border-slate-200 text-center">
                     <span className="text-4xl block mb-2">🔒</span>
                     <p className="text-slate-500 font-bold">{lang === 'th' ? 'ระบบชำระผ่านบัตรกำลังมาเร็วๆ นี้' : 'Credit Card payment coming soon'}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Slip Upload Area */}
            {(selectedPayment === 'PROMPTPAY' || selectedPayment === 'BANK') && (
              <div className="mt-8">
                <label className="block text-sm font-bold text-slate-700 mb-3">
                  {lang === 'th' ? 'แนบหลักฐานการชำระเงิน' : 'Upload Payment Slip'}
                </label>
                <div className="border-2 border-dashed border-blue-100 rounded-3xl p-10 flex flex-col items-center justify-center bg-blue-50/20 hover:bg-blue-50/50 transition-all cursor-pointer group">
                  <span className="text-3xl mb-2 group-hover:scale-110 transition-transform">📸</span>
                  <p className="text-xs font-bold text-blue-400">{lang === 'th' ? 'คลิกเพื่อเลือกไฟล์รูปภาพ' : 'Click to select image file'}</p>
                  <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-tighter">JPG, PNG, PDF up to 5MB</p>
                </div>
              </div>
            )}
          </div>

          <div className="bg-white rounded-3xl border border-blue-50 p-8 shadow-sm">
            <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              <RaccoonIcon className="w-6 h-6 text-blue-600" />
              {t.summary}
            </h2>
            <div className="space-y-6">
              {cartItems.map((item) => (
                <div key={item.id} className="flex items-center gap-6 pb-6 border-b border-slate-50 last:border-0 last:pb-0">
                  <div className="w-16 h-16 rounded-2xl bg-slate-50 overflow-hidden flex-shrink-0 border border-slate-100">
                    <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-slate-800">{item.name}</h4>
                    <p className="text-sm text-slate-500">Qty: {item.quantity}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-blue-900">฿{item.price * item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-3xl border border-blue-50 p-8 shadow-lg shadow-blue-100/50 sticky top-24">
            <h2 className="text-xl font-bold text-slate-800 mb-6">{t.total}</h2>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-slate-500">
                <span>{t.subtotal}</span>
                <span>฿{subtotal}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>{t.shipping}</span>
                <span className="text-green-600 font-bold">{t.free}</span>
              </div>
              <div className="h-px bg-slate-100 my-4" />
              <div className="flex justify-between items-end">
                <span className="font-bold text-slate-800">{t.total}</span>
                <span className="text-3xl font-black text-blue-900 leading-none">฿{total}</span>
              </div>
            </div>
            <button 
              onClick={handleConfirm}
              className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 flex items-center justify-center gap-2"
            >
              <span>{t.confirmOrder}</span>
              <span className="text-lg">→</span>
            </button>
            <div className="mt-6 flex items-center justify-center gap-2 text-slate-400">
              <span className="text-xs font-bold uppercase tracking-widest">Rocky safe checkout</span>
              <RaccoonIcon className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
