
import React from 'react';
import { MOCK_PRODUCTS } from '../constants';
import { Product, Language } from '../types';
import { translations } from '../translations';

interface CategoriesProps {
  lang: Language;
  selectedCategory: string | null;
  onSelectCategory: (category: string | null) => void;
  addToCart: (product: Product) => void;
  onViewDetail: (product: Product) => void;
}

const Categories: React.FC<CategoriesProps> = ({ lang, selectedCategory, onSelectCategory, addToCart, onViewDetail }) => {
  const t = translations[lang];
  
  const categoryMap: Record<string, string> = {
    'Notebooks': t.catNotebooks,
    'Pens': t.catWriting,
    'Writing': t.catWriting,
    'Storage': t.catStorage,
    'Planners': t.catPlanners,
    'IT': t.catIT,
    'Uniforms': t.catUniforms,
    'Decor': 'Washi & Decor'
  };

  const categories = ['All', ...Array.from(new Set(MOCK_PRODUCTS.map(p => p.category)))];

  const filteredProducts = selectedCategory && selectedCategory !== 'All'
    ? MOCK_PRODUCTS.filter(p => p.category === selectedCategory)
    : MOCK_PRODUCTS;

  return (
    <div className="px-6 py-12 max-w-7xl mx-auto animate-in fade-in duration-500">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-blue-900 mb-4">{t.categories}</h1>
        <p className="text-slate-500 max-w-2xl mx-auto">
          {lang === 'th' 
            ? 'เลือกดูอุปกรณ์การเรียนและแกดเจ็ตที่ร็อกกี้คัดสรรมาเพื่อการเรียนที่มีสิทธิภาพสูงสุด' 
            : 'Explore study supplies and gadgets curated by Rocky for maximum efficiency.'}
        </p>
      </div>

      {/* Category Filter Chips */}
      <div className="flex flex-wrap justify-center gap-3 mb-12">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => onSelectCategory(cat === 'All' ? null : cat)}
            className={`px-6 py-2.5 rounded-2xl text-sm font-bold transition-all border ${
              (cat === 'All' && !selectedCategory) || selectedCategory === cat
                ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-100'
                : 'bg-white text-slate-500 border-slate-100 hover:border-blue-200 hover:text-blue-600'
            }`}
          >
            {cat === 'All' ? t.allProducts : (categoryMap[cat] || cat)}
          </button>
        ))}
      </div>

      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} addToCart={addToCart} lang={lang} onViewDetail={onViewDetail} />
          ))}
        </div>
      ) : (
        <div className="text-center py-24 bg-white rounded-3xl border border-dashed border-slate-200">
          <span className="text-4xl block mb-4">🦝</span>
          <p className="text-slate-500 font-medium">{t.noProducts}</p>
        </div>
      )}
    </div>
  );
};

const ProductCard: React.FC<{ product: Product, addToCart: (product: Product) => void, lang: Language, onViewDetail: (product: Product) => void }> = ({ product, addToCart, lang, onViewDetail }) => {
  const t = translations[lang];
  return (
    <div className="group bg-white rounded-3xl overflow-hidden border border-blue-50 hover:shadow-xl hover:shadow-blue-100 transition-all duration-300 flex flex-col h-full">
      <div 
        className="relative aspect-square overflow-hidden bg-slate-50 cursor-pointer"
        onClick={() => onViewDetail(product)}
      >
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        {product.isHot && (
          <span className="absolute top-4 left-4 bg-orange-500 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest shadow-lg">
            Hot
          </span>
        )}
        {product.discountPrice && (
          <span className="absolute top-4 right-4 bg-red-500 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest shadow-lg">
            Sale
          </span>
        )}
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-bold text-blue-500 uppercase tracking-wide">{product.category}</span>
          <div className="flex items-center gap-1">
            <span className="text-yellow-400">★</span>
            <span className="text-xs font-bold text-slate-600">{product.rating}</span>
          </div>
        </div>
        <h3 
          className="text-lg font-bold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors cursor-pointer"
          onClick={() => onViewDetail(product)}
        >
          {product.name}
        </h3>
        <p className="text-sm text-slate-500 line-clamp-2 mb-4 leading-relaxed flex-grow">
          {product.description}
        </p>
        <div className="mt-auto pt-4 border-t border-slate-50 flex items-center justify-between">
          <div className="flex flex-col">
            {product.discountPrice ? (
              <>
                <span className="text-xs text-slate-400 line-through">฿{product.price}</span>
                <span className="text-xl font-bold text-red-600">฿{product.discountPrice}</span>
              </>
            ) : (
              <span className="text-xl font-bold text-blue-900">฿{product.price}</span>
            )}
          </div>
          <button 
            onClick={() => addToCart(product)}
            className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-blue-600 hover:text-white transition-all active:scale-95"
          >
            {t.addToCart}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Categories;
