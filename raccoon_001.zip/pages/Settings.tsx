
import React, { useState, useEffect } from 'react';
import { Language, User } from '../types';
import { translations } from '../translations';
import { RaccoonIcon } from '../constants';

interface SettingsProps {
  lang: Language;
  setLang: (lang: Language) => void;
  user: User;
  setUser: (user: User) => void;
}

const Settings: React.FC<SettingsProps> = ({ lang, setLang, user, setUser }) => {
  const t = translations[lang];
  const [isSaved, setIsSaved] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Local form state
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    goal: lang === 'th' ? 'สอบติดมหาวิทยาลัยในฝัน' : 'Getting into my dream university'
  });

  const [toggles, setToggles] = useState({
    darkMode: false,
    newsletter: true,
    orderUpdates: true,
    privacyMode: false
  });

  const handleSave = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    setUser({
      ...user,
      name: formData.name,
      email: formData.email
    });
    
    setIsLoading(false);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const Toggle = ({ label, active, onClick }: { label: string, active: boolean, onClick: () => void }) => (
    <div className="flex items-center justify-between p-4 bg-slate-50/50 rounded-2xl border border-slate-100">
      <span className="text-sm font-bold text-slate-700">{label}</span>
      <button 
        onClick={onClick}
        className={`w-12 h-6 rounded-full p-1 transition-all ${active ? 'bg-blue-600' : 'bg-slate-200'}`}
      >
        <div className={`w-4 h-4 bg-white rounded-full transition-transform ${active ? 'translate-x-6' : 'translate-x-0'}`} />
      </button>
    </div>
  );

  return (
    <div className="px-6 py-12 max-w-4xl mx-auto animate-in fade-in duration-500">
      <div className="flex items-center gap-4 mb-10">
        <div className="bg-blue-600 p-2 rounded-2xl text-white shadow-lg shadow-blue-100">
          <RaccoonIcon className="w-8 h-8" fill="white" />
        </div>
        <h1 className="text-3xl font-black text-blue-900 tracking-tight">{t.settings}</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        <div className="md:col-span-2 space-y-8">
          
          {/* Profile Info Section */}
          <section className="bg-white rounded-3xl p-8 border border-blue-50 shadow-sm">
            <h2 className="text-lg font-black text-slate-800 mb-6 flex items-center gap-2">
              <span className="text-blue-500">👤</span> {t.profileInfo}
            </h2>
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{t.name}</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{t.email}</label>
                <input 
                  type="email" 
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                />
              </div>
              <div className="space-y-1 pt-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{lang === 'th' ? 'เป้าหมายการเรียน' : 'Study Goal'}</label>
                <textarea 
                  value={formData.goal}
                  onChange={(e) => setFormData({...formData, goal: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-5 py-3 text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all h-24 resize-none"
                />
              </div>
            </div>
          </section>

          {/* Appearance Section */}
          <section className="bg-white rounded-3xl p-8 border border-blue-50 shadow-sm">
            <h2 className="text-lg font-black text-slate-800 mb-6 flex items-center gap-2">
              <span className="text-blue-500">🎨</span> {t.appearance}
            </h2>
            <div className="space-y-4">
              <Toggle 
                label={t.darkMode} 
                active={toggles.darkMode} 
                onClick={() => setToggles({...toggles, darkMode: !toggles.darkMode})} 
              />
              <div className="flex items-center justify-between p-4 bg-slate-50/50 rounded-2xl border border-slate-100">
                <span className="text-sm font-bold text-slate-700">{t.language}</span>
                <select 
                  value={lang} 
                  onChange={(e) => setLang(e.target.value as Language)}
                  className="bg-white border border-slate-200 rounded-xl px-4 py-1.5 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="th">ภาษาไทย</option>
                  <option value="en">English</option>
                </select>
              </div>
            </div>
          </section>

          {/* Notifications Section */}
          <section className="bg-white rounded-3xl p-8 border border-blue-50 shadow-sm">
            <h2 className="text-lg font-black text-slate-800 mb-6 flex items-center gap-2">
              <span className="text-blue-500">🔔</span> {t.notifications}
            </h2>
            <div className="space-y-4">
              <Toggle 
                label={t.newsletter} 
                active={toggles.newsletter} 
                onClick={() => setToggles({...toggles, newsletter: !toggles.newsletter})} 
              />
              <Toggle 
                label={t.orderUpdates} 
                active={toggles.orderUpdates} 
                onClick={() => setToggles({...toggles, orderUpdates: !toggles.orderUpdates})} 
              />
            </div>
          </section>
        </div>

        <div className="md:col-span-1">
          <div className="bg-white rounded-3xl p-8 border border-blue-50 shadow-lg shadow-blue-100/50 sticky top-24">
            <div className="text-center mb-6">
               <span className="text-4xl">🦝</span>
               <p className="text-xs text-slate-400 mt-2 font-bold uppercase tracking-widest">Rocky is waiting!</p>
            </div>
            <p className="text-sm text-slate-500 mb-8 leading-relaxed text-center">
              {lang === 'th' ? 'อย่าลืมบันทึกข้อมูลก่อนปิดหน้านี้นะครับ!' : "Don't forget to save before leaving!"}
            </p>
            <button 
              onClick={handleSave}
              disabled={isLoading}
              className={`w-full py-4 rounded-2xl font-black transition-all shadow-lg flex items-center justify-center gap-2 ${
                isSaved 
                ? 'bg-green-500 text-white shadow-green-100' 
                : 'bg-blue-600 text-white shadow-blue-200 hover:bg-blue-700 disabled:bg-blue-300'
              }`}
            >
              {isLoading && <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
              {isSaved ? t.saved : t.saveSettings}
            </button>
            <div className="mt-6 flex items-center justify-center gap-2 opacity-30 grayscale pointer-events-none">
                <RaccoonIcon className="w-4 h-4" />
                <span className="text-[8px] font-black uppercase tracking-widest text-slate-900">Lab Settings v1.2</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
