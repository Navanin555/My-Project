
import React from 'react';
import { User, Language, Page } from '../types';
import { translations } from '../translations';
import { RaccoonIcon } from '../constants';

interface ProfileProps {
  user: User;
  lang: Language;
  setCurrentPage: (page: Page) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, lang, setCurrentPage }) => {
  const t = translations[lang];

  return (
    <div className="px-6 py-12 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-white rounded-[2.5rem] border border-blue-50 overflow-hidden shadow-sm">
        {/* Cover Section */}
        <div className="h-48 bg-gradient-to-r from-blue-400 to-blue-600 relative">
          <div className="absolute top-4 right-8 opacity-20 transform rotate-12">
            <RaccoonIcon className="w-40 h-40" fill="white" />
          </div>
          <div className="absolute -bottom-16 left-8 w-32 h-32 rounded-[2rem] border-8 border-white overflow-hidden shadow-2xl bg-blue-100">
            <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Info Section */}
        <div className="pt-20 pb-12 px-8">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-8">
            <div className="space-y-4 max-w-xl">
              <div>
                <h1 className="text-4xl font-black text-slate-800 tracking-tight">{user.name}</h1>
                <p className="text-slate-400 font-bold">{user.email}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <span className="bg-blue-50 text-blue-600 text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest">{t.premiumMember}</span>
                <span className="bg-slate-50 text-slate-500 text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest">{t.since} {user.joinDate}</span>
              </div>
              <div className="bg-slate-50/50 p-6 rounded-3xl border border-slate-100">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">
                  {lang === 'th' ? '🎯 เป้าหมายปัจจุบัน' : '🎯 Current Goal'}
                </h3>
                <p className="text-slate-600 font-medium leading-relaxed italic">
                  "{lang === 'th' ? 'สอบติดมหาวิทยาลัยในฝัน' : 'Getting into my dream university'}"
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => setCurrentPage(Page.SETTINGS)}
                className="bg-blue-600 text-white px-8 py-3 rounded-2xl text-sm font-black hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 flex items-center gap-2"
              >
                <span>⚙️</span> {t.settings}
              </button>
              <button className="bg-white border border-slate-200 text-slate-600 px-6 py-3 rounded-2xl text-sm font-bold hover:bg-slate-50 transition-all">
                {t.editProfile}
              </button>
            </div>
          </div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatCard label={t.totalOrders} value="12" icon="📦" />
            <StatCard label={t.wishlist} value="45" icon="❤️" />
            <StatCard label={t.studyPoints} value="1,250" icon="✨" />
            <StatCard label={lang === 'th' ? 'ชั่วโมงการเรียน' : 'Study Hours'} value="320h" icon="⏰" />
          </div>

          <div className="mt-12 p-8 bg-blue-50 rounded-[2rem] border border-blue-100 flex flex-col md:flex-row items-center justify-between gap-6">
             <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-3xl shadow-sm">
                   🦝
                </div>
                <div>
                   <h4 className="text-blue-900 font-black text-lg">{lang === 'th' ? 'คลับแรคคูนเรียนเก่ง' : 'Raccoon Study Club'}</h4>
                   <p className="text-blue-600 text-sm font-bold">{lang === 'th' ? 'คุณอยู่ในลำดับที่ 42 ของประเทศ!' : 'You are ranked #42 nationwide!'}</p>
                </div>
             </div>
             <button className="bg-blue-600 text-white px-8 py-3 rounded-2xl text-sm font-black hover:bg-blue-700 transition-all shadow-lg shadow-blue-100">
               {lang === 'th' ? 'ดูอันดับทั้งหมด' : 'View Leaderboard'}
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon }: { label: string, value: string, icon: string }) => (
  <div className="bg-white border border-slate-100 p-8 rounded-[2rem] hover:border-blue-200 hover:shadow-xl hover:shadow-blue-50 transition-all group">
    <div className="flex items-center justify-between mb-4">
       <span className="text-2xl group-hover:scale-110 transition-transform">{icon}</span>
       <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
    </div>
    <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest block mb-1">{label}</span>
    <span className="text-3xl font-black text-blue-900">{value}</span>
  </div>
);

export default Profile;
