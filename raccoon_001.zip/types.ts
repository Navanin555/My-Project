
export interface Product {
  id: string;
  name: string;
  price: number;
  discountPrice?: number;
  description: string;
  category: string;
  imageUrl: string;
  isHot: boolean;
  rating: number;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  joinDate: string;
}

export enum Page {
  LOGIN = 'LOGIN',
  HOME = 'HOME',
  HOT_PRODUCTS = 'HOT_PRODUCTS',
  CATEGORIES = 'CATEGORIES',
  ACCOUNT = 'ACCOUNT',
  PROFILE = 'PROFILE',
  CHECKOUT = 'CHECKOUT',
  PROMOTIONS = 'PROMOTIONS',
  PRODUCT_DETAIL = 'PRODUCT_DETAIL',
  SETTINGS = 'SETTINGS'
}

export type Language = 'en' | 'th';
