
import React from 'react';
import { Product } from './types';

export const MOCK_PRODUCTS: Product[] = [
  // New Items from Images
  {
    id: 'lamy-abc-1',
    name: 'Rocky Beginner Fountain Pen',
    price: 790,
    description: 'A classic maple wood fountain pen designed for beginners. Features ergonomic blue grips and a sturdy steel nib. Perfect for learning elegant handwriting. 🖋️',
    category: 'Writing',
    imageUrl: 'https://www.monet.asia/wp-content/uploads/EKSG-PHC_product_SILVER.jpg',
    isHot: true,
    rating: 4.9
  },
  {
    id: 'masterart-60',
    name: 'Rocky Duo-Tone Pencils (60 Colors)',
    price: 350,
    description: 'Double the shades, double the creativity! 30 bi-coloured pencils providing 60 vibrant colors. Premium grade lead for extra smooth coverage and break resistance. 🎨',
    category: 'Writing',
    imageUrl: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: false,
    rating: 4.8
  },
  // Stationery - Notebooks
  {
    id: '1',
    name: 'Raccoon Sketchbook',
    price: 250,
    description: 'Minimalist A5 sketchbook with premium 120gsm cream paper. Perfect for charcoal, ink, and Rocky-inspired doodles.',
    category: 'Notebooks',
    imageUrl: 'https://m.media-amazon.com/images/I/81c3hQQAOaL.jpg',
    isHot: true,
    rating: 4.9
  },
  {
    id: 'nb2',
    name: 'Rocky Grid Journal',
    price: 180,
    description: 'B5 Grid notebook with blue soft-touch cover. Ideal for math and bullet journaling.',
    category: 'Notebooks',
    imageUrl: 'https://down-th.img.susercontent.com/file/th-11134207-7ras8-m112qilaylnsf4@resize_w450_nl.webp',
    isHot: false,
    rating: 4.7
  },
  // Stationery - Writing
  {
    id: '2',
    name: 'Sky Blue Gel Pen Set',
    price: 120,
    description: 'Set of 5 smooth-writing 0.5mm gel pens in varying shades of sky and ocean blue. Long-lasting and smudge-free.',
    category: 'Pens',
    imageUrl: 'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: true,
    rating: 4.8
  },
  {
    id: '12',
    name: 'Raccoon Blue Fountain Pen',
    price: 1200,
    description: 'Professional grade fountain pen with a stainless steel medium nib. Includes a converter and 3 ink cartridges.',
    category: 'Writing',
    imageUrl: 'https://down-th.img.susercontent.com/file/th-11134207-7r98p-lzvktvox3s0140@resize_w450_nl.webp',
    isHot: true,
    rating: 4.9
  },
  {
    id: 'wt3',
    name: 'Pastel Raccoon Highlighters',
    price: 150,
    description: 'Set of 6 double-ended highlighters in soft aesthetic colors. Chisel and fine tip for versatility.',
    category: 'Writing',
    imageUrl: 'https://images.unsplash.com/photo-1516962080544-eac695c93791?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: false,
    rating: 4.6
  },
  // IT & Gadgets
  {
    id: 'it1',
    name: 'Rocky Pro Tablet',
    price: 15900,
    discountPrice: 14500,
    description: '11-inch high-resolution tablet for digital note-taking. Comes in "Raccoon Mist" blue with 128GB storage.',
    category: 'IT',
    imageUrl: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: true,
    rating: 4.9
  },
  {
    id: 'it2',
    name: 'Blue-Mist Wireless Mouse',
    price: 890,
    description: 'Ergonomic silent mouse with dual-mode connectivity. Matches the minimalist aesthetic of any study desk.',
    category: 'IT',
    imageUrl: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: false,
    rating: 4.7
  },
  {
    id: 'it3',
    name: 'Clicky Raccoon Keyboard',
    price: 2450,
    discountPrice: 1990,
    description: '65% mechanical keyboard with white and blue keycaps. Features Gateron Yellow switches for smooth typing.',
    category: 'IT',
    imageUrl: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: true,
    rating: 4.8
  },
  {
    id: 'it4',
    name: 'Raccoon Noise-Canceling Buds',
    price: 3200,
    discountPrice: 2800,
    description: 'Wireless earbuds with active noise cancellation. Focus on your studies without distractions. 30h battery life.',
    category: 'IT',
    imageUrl: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: true,
    rating: 4.8
  },
  {
    id: 'it5',
    name: 'Portable Raccoon Power',
    price: 1250,
    description: '10,000mAh power bank with cute raccoon graphic. Fast charging USB-C and USB-A ports.',
    category: 'IT',
    imageUrl: 'https://www.eloopthailand.com/cdn/shop/products/1649411612537.jpg?v=1686067309&width=1125',
    isHot: false,
    rating: 4.7
  },
  // School Uniforms
  {
    id: 'uni1',
    name: 'Premium White School Shirt',
    price: 450,
    description: 'Anti-wrinkle cotton blend school shirt. Easy to iron and features a small hidden raccoon embroidery.',
    category: 'Uniforms',
    imageUrl: 'https://s.alicdn.com/@sc04/kf/Hd659c271de2b4c0ba3c34c40dab79914L/Boys-and-Girls-White-Shirt-Long-sleeved-Pocket-Student-Sky-Blue-Cotton-Shirt-School-Uniform-Shirt-for-Women.jpg',
    isHot: false,
    rating: 4.5
  },
  {
    id: 'uni2',
    name: 'Classic Blue Pleated Skirt',
    price: 550,
    description: 'High-quality fabric that keeps its shape. Adjustable waist for maximum comfort during long study hours.',
    category: 'Uniforms',
    imageUrl: 'https://image.hm.com/assets/hm/fa/c3/fac3fdeefcade117a666b20abee774bfb6ff9926.jpg?imwidth=786',
    isHot: true,
    rating: 4.7
  },
  {
    id: 'uni3',
    name: 'Rocky Comfort Trousers',
    price: 620,
    description: 'Navy blue school trousers with reinforced knees for active raccoons. Breathable and stretchable.',
    category: 'Uniforms',
    imageUrl: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: false,
    rating: 4.6
  },
  {
    id: 'uni4',
    name: 'Paw-Print School Shoes',
    price: 990,
    discountPrice: 790,
    description: 'Leather school shoes with orthotic support. The sole leaves a faint raccoon paw print in the mud!',
    category: 'Uniforms',
    imageUrl: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: true,
    rating: 4.9
  },
  {
    id: 'uni5',
    name: 'Rocky Striped School Tie',
    price: 190,
    description: 'Elegant navy and sky blue striped tie. Pre-knotted version available for younger raccoons.',
    category: 'Uniforms',
    imageUrl: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: false,
    rating: 4.4
  },
  // Storage & Planners
  {
    id: '4',
    name: 'Minimal Pencil Case',
    price: 350,
    description: 'Transparent TPU pencil case with a custom silver raccoon zipper pull. Waterproof and fits up to 20 pens.',
    category: 'Storage',
    imageUrl: 'https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: true,
    rating: 4.7
  },
  {
    id: '5',
    name: 'Study Planner 2024',
    price: 420,
    discountPrice: 350,
    description: 'A dated weekly planner with monthly goal sections and habit trackers. Includes Rocky stickers for motivation.',
    category: 'Planners',
    imageUrl: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?auto=format&fit=crop&q=80&w=600&h=600',
    isHot: true,
    rating: 5.0
  }
];

export const RaccoonIcon = ({ className = "w-6 h-6", fill = "currentColor" }: { className?: string, fill?: string }) => (
  <svg viewBox="0 0 100 100" className={className}>
    <path 
      d="M30,65 Q25,85 50,90 Q75,90 80,70 Q80,55 65,55 Q55,55 50,65" 
      fill="none" 
      stroke={fill} 
      strokeWidth="14" 
      strokeLinecap="round" 
    />
    <path d="M72,83 L78,75" stroke="white" strokeWidth="4" />
    <path d="M55,89 L50,80" stroke="white" strokeWidth="4" />
    <path d="M35,78 L30,70" stroke="white" strokeWidth="4" />
    <g transform="translate(50, 45)">
      <path d="M-8,-12 L-14,-22 L-2,-14 Z" fill={fill} />
      <path d="M8,-12 L14,-22 L2,-14 Z" fill={fill} />
      <circle cx="0" cy="0" r="14" fill={fill} />
      <path d="M-10,-2 Q0,2 10,-2 Q14,2 10,6 Q0,10 -10,6 Q-14,2 -10,-2" fill="#334155" />
      <circle cx="-6" cy="2" r="2.5" fill="white" />
      <circle cx="6" cy="2" r="2.5" fill="white" />
      <circle cx="-6" cy="2" r="1" fill="black" />
      <circle cx="6" cy="2" r="1" fill="black" />
      <circle cx="0" cy="5" r="1.5" fill="black" />
      <line x1="-16" y1="2" x2="-20" y2="1" stroke={fill} strokeWidth="1" />
      <line x1="-16" y1="4" x2="-20" y2="5" stroke={fill} strokeWidth="1" />
      <line x1="16" y1="2" x2="20" y2="1" stroke={fill} strokeWidth="1" />
      <line x1="16" y1="4" x2="20" y2="5" stroke={fill} strokeWidth="1" />
    </g>
  </svg>
);
