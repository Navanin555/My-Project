
import React, { useState } from 'react';
import { Page, User, Language, Product, CartItem } from './types';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import HotProducts from './pages/HotProducts';
import Profile from './pages/Profile';
import Account from './pages/Account';
import Categories from './pages/Categories';
import Checkout from './pages/Checkout';
import Promotions from './pages/Promotions';
import ProductDetail from './pages/ProductDetail';
import Settings from './pages/Settings';
import CartDrawer from './components/CartDrawer';
import { translations } from './translations';
import { RaccoonIcon } from './constants';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.HOME);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [lang, setLang] = useState<Language>('th');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Shopping Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Global User State
  const [user, setUser] = useState<User>({
    id: '123',
    name: 'สมชาย แรคคูน',
    email: 'somchai@raccoon.me',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200&h=200',
    joinDate: 'มีนาคม 2023'
  });

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentPage(Page.HOME);
  };

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category === 'All' ? null : category);
    setCurrentPage(Page.CATEGORIES);
  };

  const goToCheckout = () => {
    setIsCartOpen(false);
    setCurrentPage(Page.CHECKOUT);
  };

  const handleViewDetail = (product: Product) => {
    setSelectedProduct(product);
    setCurrentPage(Page.PRODUCT_DETAIL);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Cart Functions
  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const t = translations[lang];

  const renderPage = () => {
    switch (currentPage) {
      case Page.HOME:
        return (
          <Home 
            setCurrentPage={setCurrentPage} 
            lang={lang} 
            onCategorySelect={handleCategorySelect} 
          />
        );
      case Page.LOGIN:
        return <Login onLogin={handleLogin} setCurrentPage={setCurrentPage} lang={lang} />;
      case Page.HOT_PRODUCTS:
        return <HotProducts lang={lang} addToCart={addToCart} onViewDetail={handleViewDetail} />;
      case Page.CATEGORIES:
        return (
          <Categories 
            lang={lang} 
            selectedCategory={selectedCategory} 
            onSelectCategory={setSelectedCategory} 
            addToCart={addToCart}
            onViewDetail={handleViewDetail}
          />
        );
      case Page.CHECKOUT:
        return <Checkout lang={lang} cartItems={cart} />;
      case Page.PROFILE:
        return <Profile user={user} lang={lang} setCurrentPage={setCurrentPage} />;
      case Page.ACCOUNT:
        return <Account lang={lang} setCurrentPage={setCurrentPage} />;
      case Page.PROMOTIONS:
        return <Promotions lang={lang} addToCart={addToCart} onViewDetail={handleViewDetail} />;
      case Page.PRODUCT_DETAIL:
        return selectedProduct ? (
            <ProductDetail 
                product={selectedProduct} 
                lang={lang} 
                addToCart={addToCart} 
                setCurrentPage={setCurrentPage}
                onViewDetail={handleViewDetail}
            />
        ) : null;
      case Page.SETTINGS:
        return <Settings lang={lang} setLang={setLang} user={user} setUser={setUser} />;
      default:
        return (
          <Home 
            setCurrentPage={setCurrentPage} 
            lang={lang} 
            onCategorySelect={handleCategorySelect} 
          />
        );
    }
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col selection:bg-blue-100 selection:text-blue-900 bg-slate-50/50">
      <Navbar 
        currentPage={currentPage} 
        setCurrentPage={setCurrentPage} 
        isLoggedIn={isLoggedIn} 
        lang={lang}
        setLang={setLang}
        cartCount={totalCartCount}
        toggleCart={() => setIsCartOpen(!isCartOpen)}
        userName={user.name}
      />
      
      <main className="flex-grow pb-24">
        {renderPage()}
      </main>

      <CartDrawer 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        removeFromCart={removeFromCart}
        updateQuantity={updateQuantity}
        lang={lang}
        goToCheckout={goToCheckout}
      />

      <footer className="bg-white border-t border-blue-50 py-16 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex flex-col items-center md:items-start gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-blue-600 text-white p-1 rounded-xl shadow-sm">
                <RaccoonIcon className="w-8 h-8" fill="white" />
              </div>
              <div className="flex flex-col -gap-1">
                <span className="text-lg font-black text-blue-900 tracking-tighter leading-none uppercase">RACCOON</span>
                <span className="text-[10px] font-bold text-blue-400 tracking-[0.2em] leading-none uppercase">Study Lab</span>
              </div>
            </div>
            <p className="text-sm text-slate-400 max-w-xs text-center md:text-left">
              The minimalist home for student productivity. Stay focused, stay cute.
            </p>
          </div>
          <div className="flex gap-12 text-sm font-bold text-slate-500">
            <div className="flex flex-col gap-4">
              <a href="#" className="hover:text-blue-600">Privacy</a>
              <a href="#" className="hover:text-blue-600">Terms</a>
            </div>
            <div className="flex flex-col gap-4">
              <a href="#" className="hover:text-blue-600">Shipping</a>
              <a href="#" className="hover:text-blue-600">Help Center</a>
            </div>
          </div>
          <div className="flex flex-col items-center md:items-end gap-2">
             <div className="flex gap-4 mb-2">
                <span className="w-8 h-8 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 cursor-pointer hover:bg-blue-50 hover:text-blue-600 transition-all">FB</span>
                <span className="w-8 h-8 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 cursor-pointer hover:bg-blue-50 hover:text-blue-600 transition-all">IG</span>
             </div>
             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">© 2024 Raccoon Lab</p>
          </div>
        </div>
      </footer>

      {/* Persistent Call to Action for Mobile */}
      {currentPage !== Page.CHECKOUT && (
        <div className="md:hidden fixed bottom-6 left-6 right-6 z-50">
          <button 
            onClick={() => setCurrentPage(Page.CATEGORIES)}
            className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold shadow-2xl shadow-blue-200 flex items-center justify-center gap-2 border border-blue-500"
          >
            <span>{t.exploreSupplies}</span>
            <span>→</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default App;
