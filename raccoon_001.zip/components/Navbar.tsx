
import React, { useState, useRef, useEffect } from 'react';
import { Page, Language } from '../types';
import { RaccoonIcon } from '../constants';
import { translations } from '../translations';

interface NavbarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  isLoggedIn: boolean;
  lang: Language;
  setLang: (lang: Language) => void;
  cartCount: number;
  toggleCart: () => void;
  userName: string;
}

interface Notification {
  id: string;
  text: string;
  time: string;
  isRead: boolean;
  type: 'order' | 'promo' | 'system';
}

const Navbar: React.FC<NavbarProps> = ({ 
  currentPage, 
  setCurrentPage, 
  isLoggedIn, 
  lang, 
  setLang,
  cartCount,
  toggleCart,
  userName
}) => {
  const t = translations[lang];
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([
    { 
      id: '1', 
      text: lang === 'th' ? 'ออเดอร์ #RL-4921 กำลังเดินทางไปหาคุณแล้ว! 🦝' : 'Order #RL-4921 is on its way to you! 🦝', 
      time: '2m ago', 
      isRead: false,
      type: 'order'
    },
    { 
      id: '2', 
      text: lang === 'th' ? 'ร็อกกี้ขอมอบส่วนลด 10% สำหรับการเรียนวันนี้! ใช้โค้ด: ROCKYSTUDY' : 'Rocky gives you 10% off for studying today! Code: ROCKYSTUDY', 
      time: '1h ago', 
      isRead: false,
      type: 'promo'
    },
    { 
      id: '3', 
      text: lang === 'th' ? 'สินค้าใหม่: Rocky Pro Tablet วางจำหน่ายแล้ว!' : 'New Item: Rocky Pro Tablet is now available!', 
      time: '5h ago', 
      isRead: true,
      type: 'system'
    }
  ]);

  const dropdownRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
    setIsDropdownOpen(false);
    setIsNotifOpen(false);
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-blue-100 px-6 py-4 flex items-center justify-between">
      <div 
        className="flex items-center gap-2 cursor-pointer group"
        onClick={() => navigateTo(Page.HOME)}
      >
        <div className="bg-blue-600 text-white p-1 rounded-xl group-hover:bg-blue-700 transition-colors shadow-sm">
          <RaccoonIcon className="w-8 h-8" fill="white" />
        </div>
        <div className="flex flex-col -gap-1">
          <span className="text-lg font-black text-blue-900 tracking-tighter leading-none">RACCOON</span>
          <span className="text-[10px] font-bold text-blue-400 tracking-[0.2em] leading-none uppercase">Study Lab</span>
        </div>
      </div>

      <div className="hidden md:flex items-center gap-6">
        <button 
          onClick={() => navigateTo(Page.HOME)}
          className={`text-sm font-bold transition-colors ${currentPage === Page.HOME ? 'text-blue-600' : 'text-slate-400 hover:text-blue-500'}`}
        >
          {t.navHome}
        </button>
        <button 
          onClick={() => navigateTo(Page.CATEGORIES)}
          className={`text-sm font-bold transition-colors ${currentPage === Page.CATEGORIES ? 'text-blue-600' : 'text-slate-400 hover:text-blue-500'}`}
        >
          {t.navCategories}
        </button>
        <button 
          onClick={() => navigateTo(Page.HOT_PRODUCTS)}
          className={`text-sm font-bold transition-colors ${currentPage === Page.HOT_PRODUCTS ? 'text-blue-600' : 'text-slate-400 hover:text-blue-500'}`}
        >
          {t.navPopular}
        </button>
        <button 
          onClick={() => navigateTo(Page.PROMOTIONS)}
          className={`text-sm font-bold transition-colors ${currentPage === Page.PROMOTIONS ? 'text-red-500' : 'text-slate-400 hover:text-red-400'}`}
        >
          {t.navPromos}
        </button>
        
        <div className="h-4 w-px bg-slate-100" />

        <button 
          onClick={() => setLang(lang === 'en' ? 'th' : 'en')}
          className="flex items-center gap-1.5 px-2 py-1 rounded-lg border border-slate-100 bg-slate-50 text-slate-600 hover:bg-white transition-all text-[10px] font-black"
        >
          {lang === 'en' ? 'EN' : 'TH'}
        </button>

        <div className="flex items-center gap-2">
          {/* Notification Bell */}
          <div className="relative" ref={notifRef}>
            <button 
              onClick={() => setIsNotifOpen(!isNotifOpen)}
              className="relative p-2 text-slate-500 hover:text-blue-600 transition-colors"
            >
              <span className="text-xl">🔔</span>
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 bg-red-500 text-white text-[8px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {isNotifOpen && (
              <div className="absolute right-0 mt-3 w-80 bg-white rounded-2xl shadow-2xl shadow-blue-100/50 border border-blue-50 py-4 animate-in fade-in zoom-in-95 duration-200">
                <div className="px-5 pb-3 border-b border-slate-50 flex items-center justify-between">
                  <h3 className="text-sm font-black text-blue-900 tracking-tight">{t.notificationTitle}</h3>
                  {unreadCount > 0 && (
                    <button 
                      onClick={markAllRead}
                      className="text-[10px] font-bold text-blue-500 hover:underline"
                    >
                      {t.markAllRead}
                    </button>
                  )}
                </div>
                <div className="max-h-64 overflow-y-auto">
                  {notifications.length > 0 ? (
                    notifications.map(notif => (
                      <div 
                        key={notif.id}
                        onClick={() => markAsRead(notif.id)}
                        className={`px-5 py-3 hover:bg-blue-50 transition-colors cursor-pointer border-b border-slate-50 last:border-0 relative ${!notif.isRead ? 'bg-blue-50/30' : ''}`}
                      >
                        {!notif.isRead && <div className="absolute left-2 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-blue-500 rounded-full" />}
                        <div className="flex gap-3">
                          <span className="text-lg">
                            {notif.type === 'order' ? '📦' : notif.type === 'promo' ? '🎁' : '⚙️'}
                          </span>
                          <div className="flex-1">
                            <p className={`text-xs leading-relaxed ${notif.isRead ? 'text-slate-500' : 'text-slate-800 font-bold'}`}>
                              {notif.text}
                            </p>
                            <span className="text-[9px] text-slate-400 mt-1 block uppercase font-bold tracking-widest">{notif.time}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="px-5 py-8 text-center">
                      <p className="text-xs text-slate-400">{t.noNotifications}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <button 
            onClick={toggleCart}
            className="relative p-2 text-slate-500 hover:text-blue-600 transition-colors"
          >
            <span className="text-xl">🛒</span>
            {cartCount > 0 && (
              <span className="absolute top-1.5 right-1.5 bg-orange-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-white">
                {cartCount}
              </span>
            )}
          </button>
        </div>

        {isLoggedIn ? (
          <div className="relative" ref={dropdownRef}>
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-10 h-10 rounded-xl bg-blue-100 border border-blue-200 overflow-hidden ring-2 ring-transparent hover:ring-blue-100 transition-all flex items-center justify-center"
            >
              <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100&h=100" alt="Avatar" className="w-full h-full object-cover" />
            </button>

            {isDropdownOpen && (
              <div className="absolute right-0 mt-3 w-56 bg-white rounded-2xl shadow-2xl shadow-blue-100/50 border border-blue-50 py-3 animate-in fade-in zoom-in-95 duration-200">
                <div className="px-5 py-2 border-b border-slate-50 mb-2">
                   <p className="text-xs font-black text-blue-900 truncate">{userName}</p>
                   <p className="text-[10px] text-slate-400">Premium Member</p>
                </div>
                <button 
                  onClick={() => navigateTo(Page.PROFILE)}
                  className="w-full text-left px-5 py-2.5 text-sm font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors flex items-center gap-3"
                >
                  <span>👤</span> {t.editProfile}
                </button>
                <button 
                  onClick={() => navigateTo(Page.ACCOUNT)}
                  className="w-full text-left px-5 py-2.5 text-sm font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors flex items-center gap-3"
                >
                  <span>📦</span> {t.navOrders}
                </button>
                <button 
                  onClick={() => navigateTo(Page.SETTINGS)}
                  className="w-full text-left px-5 py-2.5 text-sm font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors flex items-center gap-3"
                >
                  <span>⚙️</span> {t.settings}
                </button>
                <div className="h-px bg-slate-50 my-2" />
                <button 
                  onClick={() => window.location.reload()}
                  className="w-full text-left px-5 py-2.5 text-sm font-bold text-red-500 hover:bg-red-50 transition-colors flex items-center gap-3"
                >
                  <span>🚪</span> {t.logout}
                </button>
              </div>
            )}
          </div>
        ) : (
          <button 
            onClick={() => navigateTo(Page.LOGIN)}
            className="bg-blue-600 text-white px-5 py-2 rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
          >
            {t.navSignIn}
          </button>
        )}
      </div>

      <div className="md:hidden flex items-center gap-4">
        <button onClick={() => setIsNotifOpen(!isNotifOpen)} className="relative text-xl">
           🔔
           {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] font-bold w-3 h-3 rounded-full flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </button>
        <button onClick={toggleCart} className="relative text-xl">
           🛒
           {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-[8px] font-bold w-3 h-3 rounded-full flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </button>
        <button onClick={() => navigateTo(Page.SETTINGS)} className="text-blue-600">
           <span className="text-xl">⚙️</span>
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
