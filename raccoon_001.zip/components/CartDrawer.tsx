
import React from 'react';
import { CartItem, Language, Page } from '../types';
import { translations } from '../translations';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, delta: number) => void;
  lang: Language;
  goToCheckout: () => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ 
  isOpen, 
  onClose, 
  cartItems, 
  removeFromCart, 
  updateQuantity,
  lang,
  goToCheckout
}) => {
  const t = translations[lang];
  const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] overflow-hidden">
      <div 
        className="absolute inset-0 bg-slate-900/20 backdrop-blur-sm transition-opacity" 
        onClick={onClose} 
      />
      <div className="absolute inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md bg-white shadow-2xl animate-in slide-in-from-right duration-300 flex flex-col">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
            <h2 className="text-xl font-bold text-slate-800">{t.shoppingCart}</h2>
            <button onClick={onClose} className="p-2 hover:bg-slate-50 rounded-full text-slate-400">
              ✕
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-6 px-6">
            {cartItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400">
                <span className="text-6xl mb-4">🦝</span>
                <p>{t.cartEmpty}</p>
              </div>
            ) : (
              <div className="space-y-6">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex gap-4 p-4 bg-blue-50/30 rounded-2xl border border-blue-50">
                    <div className="w-20 h-20 rounded-xl bg-white overflow-hidden border border-slate-100 flex-shrink-0">
                      <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="font-bold text-slate-800 text-sm">{item.name}</h4>
                        <p className="text-blue-600 font-bold text-xs mt-1">฿{item.price}</p>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-2 bg-white rounded-lg px-2 py-1 border border-slate-100">
                          <button onClick={() => updateQuantity(item.id, -1)} className="text-blue-500 font-bold px-1">－</button>
                          <span className="text-xs font-bold w-4 text-center">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, 1)} className="text-blue-500 font-bold px-1">＋</button>
                        </div>
                        <button onClick={() => removeFromCart(item.id)} className="text-xs text-red-400 font-medium hover:underline">
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {cartItems.length > 0 && (
            <div className="border-t border-slate-100 p-6 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">{t.total}</span>
                <span className="text-2xl font-bold text-blue-900">฿{total}</span>
              </div>
              <button 
                onClick={goToCheckout}
                className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
              >
                {t.checkout}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CartDrawer;
