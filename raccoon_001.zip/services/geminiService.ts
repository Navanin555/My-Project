
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getRaccoonAdvice = async (userName: string, interest: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are 'Rocky the Raccoon', a study mascot for an online shop. The user '${userName}' is interested in '${interest}'. Give a short, cute, minimalist recommendation for school supplies in Thai language. Keep it under 2 sentences. Include a raccoon emoji.`,
      config: {
        temperature: 0.7,
        topP: 0.9,
      },
    });
    return response.text || "ว้าว! สนใจอุปกรณ์การเรียนเหรอครับ ลองดูสมุดโน้ตแรคคูนของเราดูนะ 🦝";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "ขอโทษครับ พอดีแรคคูนหลับอยู่ ลองใหม่ภายหลังนะ! 🦝";
  }
};
